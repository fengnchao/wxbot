# 四项历史回归失败修复记录

本次核对发现四项均为旧测试预期，生产代码无需修改。修改前独立运行四个原用例，确认均失败；修改后连同补充对照，共 8 项通过。

全项目回归结果：**1584 通过、0 失败**，耗时 121.72 秒。仍有 3 条 Pillow `Image.getdata` 弃用提示，来自原头像归一化代码，不影响本次测试通过。

执行命令（项目根目录）：

```powershell
.\.venv\Scripts\python.exe -m pytest --basetemp tests/.tmp-four-failures-full-1107a --tb=short
```

控制台完整结果保存在本地 `tests/.four-failures-full.log`。

| 原失败 | 源码依据 | 修正与补充 |
|---|---|---|
| 固定要求 6 个 Skill | 当前 manifest 导出 roles/tools，包含新增的 IndexTTS | 校验所有实际技能均导出、核心技能存在，并保留引导/MCP/协议检查 |
| 未确认发送后继续剩余段 | finish_delivery + _end_reply 保留 uncertain、停止剩余段 | 分别验证 CLI 确认和显式重试，其他段完整记录不变 |
| 重启后的旧批次继续阻塞 | recover 终结旧轮并保留待核对记录 | 核对正文登记不会消除审计、新轮能继续；补 sending/confirming 仍阻塞的对照 |
| 默认要求 0.5 秒输入间隔 | validate_typing_config 与 README 默认 0.25 秒 | 同时覆盖默认 0.25 和显式 0.5 秒，保留完整正文、单次回车和剪贴板恢复 |

新测试入口：

- `tests/integration/test_portable_install.py::test_plugin_references_and_protocol_are_self_contained`
- `tests/unit/queue/test_queue_admin.py::test_multipart_cli_resolution_preserves_sent_and_stopped_parts`（sent / retry）
- `tests/unit/queue/test_queue_store.py::test_user_confirmed_text_keeps_restart_review_without_blocking_new_messages`
- `tests/unit/queue/test_queue_store.py::test_record_actual_text_does_not_release_live_delivery`（sending / confirming）
- `tests/unit/text/test_typing.py::test_typing_steps_respect_interval_and_one_final_enter`（默认 / 显式间隔）

测试按项目约定只保存在本地 `tests/`，该目录不入 Git。测试使用临时 SQLite、假窗口、假剪贴板和本机 HTTP 替身；未发真实微信，未重启现有服务。

架构图组件和连线不变；`architecture-notes/delivery-pump.md` 补充批次 done 与送达确认的区别。没有 API、数据表、配置或前端改动。
