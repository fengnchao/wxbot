# 小潮常驻角色实施计划

**目标** 小潮跟随 Butler 启停，在空闲时短时看抖音，并将一条日记保存在本机。

**设计** [改前影响报告](../../../llm%20wiki/wxbot/impacts/2026-11-05-resident-xiaochao.md)

**实现** Python 3.14、Playwright 的 Edge 持久会话、现有 Butler HTTP 入口。按以下顺序使用隔离测试验证。

- [x] `src/butler/config.py` 与 `src/butler/runtime/resident.py`。覆盖默认关闭、空闲 300 秒、每轮 180 秒、冷却 1800 秒和每日 900 秒。`ForegroundActivity.request()` 覆盖并发聊天。`ResidentRole.tick()` 先预留当日额度，结束后按浏览器活动用时退回未用的部分，失败和登录等待保留状态。
- [x] `src/butler/runtime/resident_douyin.py`。`DouyinBrowser.watch(limit, interrupted, observed)` 使用专用资料目录，只记录同一作品下实际推进的播放进度。登录验证时停止，换片后核对 ID。登录命令使用可见 Edge，活动由无窗口 Edge 执行。
- [x] `src/butler/server.py` 与 `src/butler/__main__.py`。测试开关关闭时不创建角色，启用时随 `serve()` 启停，同步和流式聊天共用前台活动计数。`resident-login` 使用配置的数据目录。角色文本放在插件内独立目录。日记从观察数据生成，支持纯文本后端时整理一次，否则写事实版。
- [x] 完成 36 项相关回归测试，实际 Edge 的离线 HTML 测试通过两条作品的播放和换片。真实抖音登录和推荐流需使用者在专用浏览器登录后验收。README 与知识图谱已更新。
