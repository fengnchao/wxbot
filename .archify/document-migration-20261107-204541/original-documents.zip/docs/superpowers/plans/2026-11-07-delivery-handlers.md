# Delivery Handlers Implementation Plan

> **For agentic workers:** Use superpowers:executing-plans in this session. 用户已授权实施第一步。

**Goal:** 拆分四类发件处理器，保留现有投递契约。
**Architecture:** DeliveryPump 统一调度，一张 outbox 按 kind 选择处理器。文字和图片共用气泡发送流程；语音持有后台准备状态，表情独立发送。
**Tech Stack:** Python 3.14、SQLite、pytest、原生 SVG/HTML。
**Spec:** `docs/superpowers/specs/2026-11-07-delivery-handlers-design.md`

## Global Constraints

- 不改数据库、HTTP、配置和管理台字段。
- 不重启服务、不发送真实微信；保留当前工作树已有修改。
- 本次在用户指定目录的 `codex/index-tts-skill` 分支工作，不提交或搬移已有未提交工作。

## Review Focus

- 混合类型保持同会话 FIFO，确认前不领取同会话后项。
- WebUI 晚到结果在关闭/删除后不能录音；语音授权变化仍需复核。
- 流式文字只有封口才允许提交，草稿归属保护不变。
- 图文包撤权/图片已粘贴的失败保留人工核对。
- 重启仅核对已有气泡，不重新发送图片、语音或文字。

## Task 1: 拆分处理器

**Files:** 修改 `src/wxbot/delivery.py`；新增 `src/wxbot/delivery_handlers/{__init__,base,bubble,text,image,voice,emoji}.py`；测试 `tests/unit/queue/test_delivery_handlers.py` 及现有 queue/media/voice 用例。
**Interfaces:** 保留 DeliveryPump 构造、enqueue/start_next/tick/close/reconcile/busy；处理器使用 start、sync_input、complete、prepare_finish、after_finish、poll、close 钩子；ActiveDelivery 和 reply_evidence 继续由旧入口导出。

- [x] 基线运行现有队列、媒体和自动语音回归。
- [x] 新增处理器可独立启动及真实 SQLite 混合类型顺序回归；运行并确认拆分入口缺失的失败。
- [x] 提取处理器与公共气泡流程；只调整既有测试调用的私有语音入口，保留断言。
- [x] 运行所有相关离线回归，核对结果。

## Task 2: 架构与知识图谱同步

**Files:** `ARCHITECTURE.html`、`architecture-notes/`、`README.md`、`llm wiki/wxbot/` 相关条目。
**Interfaces:** kind、数据库表与 HTTP 保持原状；HTML 新节点绑定对应 Markdown。

- [x] 图中补充四类处理器及统一调度说明，保留规划节点并明确状态。
- [x] 补充源码职责、图谱调用与字段血缘，追加 raw 记录后 ingest/lint。
- [x] 渲染检查 HTML、运行适当测试与 diff 检查；独立审查本次差异。

## 执行记录

- 基线：`D:/work/code/wxbot`，HEAD `20fc624bcf09e221079edd498fac85a5f2c1404f`；解释器与 REPO_ROOT 一致。
- Ruling: 就地保留已有未提交架构图和代码——用户要求接续当前项目第一步，隔离到 HEAD 会丢失当前工作基线；不自动提交其他修改。
- Pre-flight: Task 2 描述 Task 1 的最终处理器接口，依赖实现和源码核对完成后再入库。

- Task 1: complete — 核心 92 通过，相关套件 236 通过/2 个基线已有失败。
- Task 2: complete — 29 个节点映射与源码锚点通过，13 页 ingest 成功，lint 仅两条原有 pending-change。
- Final review: 独立审查已完成，无引入的正确性问题。
- Final: minor (deferred): 合成过程中删除/跳过行的专门回归用例；源码保护原样保留，现有关闭用例已通过。
- Final: Ruling: 既有状态/技能数量/输入间隔失败不进入本次结构重构 — 四项均用原始发件源码复现，保持本步行为范围；风险与详情见 verification 文档。
- 完整验证：1576 通过/4 个原有失败；未提交、未重启、未向真实微信发消息。
