# 发件重构第一步验证记录

后续更新：下文四项历史失败已完成核对及测试修正，全项目现为 1584 项通过、0 失败。
详见 [四项历史回归失败修复记录](2026-11-07-stale-regression-tests-verification.md)。下文保留第一步重构时的原始验证结果。

当前工作树：`D:/work/code/wxbot`；分支 `codex/index-tts-skill`；起点 HEAD `20fc624bcf09e221079edd498fac85a5f2c1404f`。
保留所有原有未提交修改，不自动提交、迁移数据库或重启服务。

## 结果

- 重构前相关回归：229 通过、2 个已有失败。
- 新增测试先运行：4 个处理器入口因模块不存在失败，3 个行为保持测试通过；实现后 7 项全部通过。
- 核心文字/流式/图片/自动语音回归：92 通过。
- 完整相关回归：236 通过、2 个相同的已有失败。
- 全项目 `python -m pytest`：1576 通过、4 失败、3 个 Pillow 弃用警告。
- 将拆分前 delivery.py 只在测试进程内载入，再单独运行上述 4 项：全部复现，不覆盖工作树。
- 只使用临时数据库、假窗口、假音频和随机本机端口替身；没有发送真实微信。
- 架构 HTML 渲染检查及 29 个节点 Markdown 映射检查；编辑器脚本保持原状。

## 已有失败

1. `tests/integration/test_portable_install.py::test_plugin_references_and_protocol_are_self_contained`：测试预期 6 个 Skill，当前项目有 7 个。
2. `tests/unit/queue/test_queue_admin.py::test_multipart_cli_sent_and_retry_preserve_other_parts`：预期 waiting_delivery，实际 done。
3. `tests/unit/queue/test_queue_store.py::test_user_confirmed_actual_text_is_deferred_and_does_not_release_running_old_worker`：预期 uncertain，实际 done。
4. `tests/unit/text/test_typing.py::test_typing_steps_keep_half_second_between_batches_and_one_final_enter`：预期一次粘贴，当前时序已发生两次。

本次不改变这些模块的行为或测试预期，避免结构重构夹带队列状态及输入间隔改动。

## 审查

独立审查已逐段对照拆分前源码与全部新处理器，未发现引入的正确性回归。
复核范围包括混合顺序、关闭与晚到结果、流式提交门控、图片人工核对、撤权、准确预设和单次回退。

非阻塞测试缺口暂留：后台合成中删除/跳过队列行的专门回归；源码中的失效行检查已原样保留，现有测试覆盖关闭时丢弃结果。

## 环境与图谱

首次在沙箱默认临时目录运行遇到访问权限错误；改用独立 `tests/.tmp-delivery-*` 后解决。
带 HTTP 替身的测试在允许本机回环连接的测试进程执行，避免 WinError 10013。
图谱保留两条原有 pending-change：2026-11-03-feat-voice-002-indextts、2026-11-03-indextts-enqueue-media；本次记录单独入库，不代替旧记录完成审核。
