---
type: concept
module: wiki
summary: 根目录与 Archify 架构图按节点标识读写同一套 Markdown 文档
coverage: overview
last_verified: '2026-11-07'
sources:
- path: README.md
  line: 849
  anchor: '## 架构图节点文档'
- path: README.md
  line: 859
  anchor: 'Archify 版 [项目架构图]'
changes:
- raw/changes/2026-11-07-archify-node-documents
- raw/changes/2026-11-07-architecture-node-notes
- raw/changes/2026-11-07-architecture-diagram-trim
- raw/changes/2026-11-07-delivery-handlers
---
# 架构图节点文档

根目录的 `ARCHITECTURE.html` 是独立的本地页面。节点的 `data-component`
提供显示名称，`data-note` 是文件名键。当前图有 29 个节点入口；保留节点沿用原有文档键。

节点通过点击、Enter 或空格打开对话框，显示和编辑 Markdown 源文。
首次打开文档时，用 Edge 或 Chrome 选择含 `ARCHITECTURE.html` 的项目目录。
同一个页面会话内复用目录授权；第一次保存时在项目内创建 `architecture-notes/<键>.md`。
读取或写入失败时显示原因，保存前复查文件内容，避免覆盖已检测到的外部改动。

该目录保存架构笔记，不属于运行时日记、知识库或 [[modules/wiki]] 的图谱证据。
本页不调用管理台、Butler、wxbot 或数据库。

图谱工具的来源白名单未包含根目录 HTML，因此使用 `README.md:849` 做自动锚点。
已手工核对 `ARCHITECTURE.html:79` 的节点键、`ARCHITECTURE.html:294` 的对话框、
`ARCHITECTURE.html:362` 的读取入口、`ARCHITECTURE.html:431` 的目录选择和
`ARCHITECTURE.html:464` 的文件写入流。

来源 [[raw/changes/2026-11-07-architecture-node-notes]]、[[raw/changes/2026-11-07-architecture-diagram-trim]]。


## 发件处理器节点

本次新增 delivery-pump、delivery-text、delivery-voice、delivery-image、delivery-emoji 五个文档入口，文件已创建。保留所有旧键；编辑器脚本未变。主链路仍展示目标架构，kind 与已实现处理器有明确标注，reply_type、前置 TTS 和文件发件保留为规划。


## 发件职责拆分（2026-11-07）

统一调度见 [[symbols/delivery-pump]]，文字、图片、语音、表情的准备和确认见 [[symbols/delivery-handlers]]。outbox 字段、语音授权、重试及流式契约保持原状，无迁移。

来源 [[raw/changes/2026-11-07-delivery-handlers]]。


## Archify 节点详情入口

独立页面 `.archify/architecture-wxbot-20261107-201947/wxbot.html` 保留原生节点详情、源码链接、关系与导出，在详情右侧加「文档」小按钮。按钮仅在单个节点选中时出现；多节点选择和关系详情不关联文档。

| Archify 节点 ID | 项目 architecture-notes 下的文件 |
|---|---|
| wechat | wechat-client.md |
| wxui | wechat-ui.md |
| queue | queue-storage.md |
| worker | queue-worker.md |
| butler | butler.md |
| backends | model-backends.md |
| authority | identity-tools.md |
| business | business-storage.md |
| vault | knowledge-vault.md |
| web / dashboard | dashboard.md |
| config | configuration.md |

复用原图的目录选择、原文预览、编辑和独占写入流程。目录必须包含根目录 `ARCHITECTURE.html`，而不是选择 HTML 所在的 `.archify` 子目录。同一页面会话复用授权，新文件只在明确保存时创建；预览使用 textContent。保存前重新读磁盘，发现改动或删除时保留草稿并拒绝覆盖；关闭和 Escape 保留未保存修改的确认。

编辑器挂在 `#focus-chip` 内，防止原生查看器在捕获阶段把编辑器点击识别成节点详情外点击；键盘事件不冒泡到查看器快捷键。关闭编辑器回到文档按钮。深浅主题复用查看器变量，原生 dialog 显式居中。

扩展源为同目录 `node-notes.extension.html`，`apply-node-notes.py` 幂等注入按钮与扩展，第一次执行保留 `wxbot.before-node-notes.html`。扩展不改节点、连接或生产功能，且不访问业务服务或数据库。原 Archify 回执仅验证扩展前字节；定制版本由 `node-notes.test.cjs` 使用内存句柄进行真实无头 Edge 验证，并记录当前 HTML 摘要至 `node-notes-verification.json`。

HTML 不在图谱来源白名单内，自动锚点为 `README.md:859`；手工核对 HTML 的按钮 `:5673`、文件读取 `:15145`、映射/选中判断 `:15087` / `:15171`、弹窗挂载 `:15210`、保存 `:15249`。源码分片的映射、弹窗与保存分别在 `node-notes.extension.html:73`、`:196`、`:235`。

来源 [[raw/changes/2026-11-07-archify-node-documents]]；项目图谱与浏览器笔记仍分开维护，见 [[modules/wiki]]。
