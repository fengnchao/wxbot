---
type: concept
module: wiki
summary: 按实际工作树与解释器确定开发基线，区分当前配置、生产模型链路与历史布局
coverage: overview
last_verified: '2026-11-07'
sources:
- path: README.md
  line: 125
  anchor: '## 开发基线与历史布局'
- path: README.md
  line: 597
  anchor: '## 配置'
- path: README.md
  line: 849
  anchor: '## 架构图节点文档'
- path: pyproject.toml
  line: 1
  anchor: '[project]'
- path: src/butler/defaults.py
  line: 4
  anchor: 'def butler_defaults():'
- path: src/butler/defaults.py
  line: 13
  anchor: 'def wxbot_defaults():'
- path: src/wxbot/config.py
  line: 110
  anchor: def load_config(
- path: src/wxbot/main.py
  line: 29
  anchor: def build_processor(
- path: src/wxbot/wechat/typing.py
  line: 178
  anchor: ClipboardLease(self.chunks[self.index])
- path: src/wxbot/wechat/typing.py
  line: 201
  anchor: auto.SendKeys('{Ctrl}v'
- path: src/dashboard/http.py
  line: 88
  anchor: WEBAPP_DIR = os.path.join(str(REPO_ROOT), 'web', 'dist')
- path: src/wxbot/config.py
  line: 43
  anchor: chunk_interval = typing.get(
changes:
- raw/changes/2026-11-07-archify-node-documents
- raw/changes/2026-11-03-development-doc-baseline
- raw/changes/2026-11-04-root-workspace-unification
- raw/changes/2026-11-04-index-tts-skill
- raw/changes/2026-11-04-contact-index-tts
- raw/changes/2026-11-04-webui-preset-binding
- raw/changes/2026-11-04-webui-preset-graph-note
- raw/changes/2026-11-05-contact-policy-save
- raw/changes/2026-11-05-group-auto-voice
- raw/changes/2026-11-05-contact-enrollment-and-tts-ui
- raw/changes/2026-11-05-delete-knowledge-fact
- raw/changes/2026-11-05-resident-xiaochao
- raw/changes/2026-11-05-resident-diary-web
- raw/changes/2026-11-06-resident-visible-edge
- raw/changes/2026-11-07-architecture-node-notes-readme
- raw/changes/2026-11-07-delivery-handlers
- raw/changes/2026-11-07-stale-regression-tests
---
# 开发基线与历史布局

## 术语与状态含义

基线由工作目录、Git 分支、HEAD SHA、未提交修改及解释器实际导入的代码共同确定。
`main`、正式运行目录和开发 worktree 可以处于不同进度；分支名或“曾经同 SHA”不能证明当前内容相同。
当前代码与运行进程已加载的版本也不是同一件事（`README.md:125` 开始的核对流程）。
若 `.venv` 的可编辑安装指向另一工作树，必须先识别差异，不能把另一份代码的通过结果当作本轮证据。

## 业务规则与边界

- 配置来自 `src/butler/defaults.py:4` / `:13` 等无凭据默认值，经安装向导生成；当前仓库没有独立示例 TOML。
  实际名字是 `config.butler.toml`、`config.wxbot.toml`、`config.log.toml`（`README.md:597`）。
- Python 依赖以 `pyproject.toml:1` 的声明和 uv.lock 精确版本为准；requirements.txt 是兼容 pip 清单，不能据旧注释断言 Butler 无第三方依赖。
- 生产默认 wxbot→Butler→模型；Butler 自身的 Hermes、OpenAI 兼容 API 等 provider 是正常接入方式。
  wxbot 的直接适配器属于旁路调试／旧配置兼容；带 installation 配置时禁止非 butler backend（`src/wxbot/main.py:29`）。
- 正文发送使用 `ClipboardLease` 后执行 Ctrl+V，再读回校验；控制键仍由 UI 自动化执行（`src/wxbot/wechat/typing.py:178`、`:201`）。
  默认分批间隔为 0.25 秒；full/chunked/streaming 均使用粘贴，见 `README.md:597` 后的发送章节与 `src/butler/defaults.py:13`。

## 跨层映射

[[modules/runtime]] 负责配置生成，[[modules/models]] 定义 Butler 的模型后端，[[modules/wxbot]] 持有正文粘贴与发送确认。
[[modules/web]] 的产物由 `src/dashboard/http.py:88` 的 WEBAPP_DIR 在 /app/ 提供，不由已退场的 log/server.py 提供。
[[modules/wiki]] 的 CLI 支持 `--repo-root` 显式限定开发图谱范围，不授予运行时身份或操作权限。
本次没有 API/DTO、数据库字段／迁移或异步任务变更。

## 历史坑与冲突

旧 butler/README.md、PROJECT_MEMORY.md、kmg/、hermes_butler、固定安装路径和嵌套包名不再代表当前 src/ 布局。
它们在本轮工作分支中已不存在，不能重建旧入口来满足过期说明。根 heartbeat/ 仍含受版本控制的辅助看门狗脚本，
与 src/butler/runtime/heartbeat.py 的业务心跳分开；不把整个目录忽略或删除（`README.md:125`）。
2026-11-03 的文档核对仅用显式 --repo-root 限定图谱范围，当时没有修复可编辑安装。
2026-11-04 按用户要求由主目录接管最新 main，并在主目录自己的 .venv 中离线重装本项目；
随后从仓库外以隔离模式验证四个包及 REPO_ROOT 均来自主目录 src/。
这是开发环境绑定的核验，不证明现有进程已重新加载代码；本次未启动或重启服务。
另一个 worktree 及其独立配置、数据仍保留，不能把代码目录统一当成数据库或认证迁移。

## 相关模块、接口、测试

关联 [[modules/wiki]]、[[modules/runtime]]、[[modules/models]]、[[modules/wxbot]]、[[modules/web]]。
使用静态语义等价检查确认 Python 执行 AST、Vite 执行配置、依赖项和锁文件未变；前端构建写入临时目录并运行既有假数据冒烟。
没有新增测试；本次不改变 UI 行为、真实配置、凭据或运行数据，也不启动／重启服务。

## 代码依据与修改来源

来源与锚点见本页 sources；完整核对范围、八项问题的实际处置和验证记录见
[[impacts/2026-11-03-development-doc-baseline]] 与 [[raw/changes/2026-11-03-development-doc-baseline]]。

环境绑定后续处理见 [[impacts/2026-11-04-root-workspace-unification]] 与
[[raw/changes/2026-11-04-root-workspace-unification]]；历史 raw 保持原样。


## 本次核对

[[raw/changes/2026-11-04-index-tts-skill]]：对照本次源码 diff 复核来源与行号；新增预设语音路径见 [[apis/index-tts]]，其余已述契约未改。


## 联系人语音配置核对

[[raw/changes/2026-11-04-contact-index-tts]]：新增会话授权控件与原接口消费，源码位置已核对；后端契约保持。


## 联系人语音配置核对

[[raw/changes/2026-11-04-webui-preset-binding]]：接入网页预设列表与会话默认绑定；原有接口保持，新增接口及可选音色参数见 [[apis/index-tts]]。


图谱契约说明来源：[[raw/changes/2026-11-04-webui-preset-graph-note]]。


## 策略保存复核（2026-11-05）

本次 src/dashboard/http.py 仅细化未知技能校验错误；WEBAPP_DIR、/app/ 静态文件来源与安装基线规则未改。保存锁等待修复见 [[apis/dashboard-contact-policy]]。来源 [[raw/changes/2026-11-05-contact-policy-save]]。


## 群聊采集与自动语音复核（2026-11-05）

README 追加自动语音真实 WebUI 默认、配置热读和窗口越屏恢复说明；安装路径、静态文件位置及图谱 CLI 合同不变。功能依据见 [[concepts/automatic-voice-reply]]、[[concepts/capture-viewport]]。来源 [[raw/changes/2026-11-05-group-auto-voice]]。

## 本次核对

README 补充联系人建档与 IndexTTS 界面路径，解释器、运行与配置基线沿用。 来源 [[raw/changes/2026-11-05-contact-enrollment-and-tts-ui]]。

## 本次核对

README 增补事实删除操作及接口，开发基线沿用。 来源 [[raw/changes/2026-11-05-delete-knowledge-fact]]。

## 常驻角色接入核对

`pyproject.toml` 的 `resident` 可选依赖为 Playwright，开启 [[symbols/resident-role]] 前按 README 安装。 来源 [[raw/changes/2026-11-05-resident-xiaochao]]。

## 小潮日记接入核对

README 的小潮常驻角色章节补充了本机管理台入口，构建、安装和开发基线规则继续沿用。 来源 [[raw/changes/2026-11-05-resident-diary-web]]。

README 补充了小潮的有窗口运行方式和验证等待步骤。来源 [[raw/changes/2026-11-06-resident-visible-edge]]。

README 末尾补充了独立架构图的节点文档入口。原开发基线和配置章节的锚点仍分别位于第 125 和 596 行。
文档权限和文件映射见 [[concepts/architecture-node-notes]]。来源 [[raw/changes/2026-11-07-architecture-node-notes-readme]]。


## 发件拆分文档复核

README 的 wxbot 文件职责新增 delivery_handlers，架构章节记录第一步与后续规划的界限；配置、安装和图谱维护流程未变。

来源 [[raw/changes/2026-11-07-delivery-handlers]]。


## 输入时序回归基线

缺省 chunk_interval 为 0.25 秒；显式 0.5 秒仍受支持。本地输入回归分别使用缺省/显式配置，验证到期前不提前粘贴、到期后完整粘贴、仅一次回车及剪贴板恢复。本次不修改输入逻辑或默认配置。

来源 [[raw/changes/2026-11-07-stale-regression-tests]]。


## Archify 本地扩展的基线

README 仅在架构图节点文档章节追加 Archify 文档按钮用法，原配置、运行与开发基线段落及来源锚点保持原位。独立 Archify 图仍按提交 `20fc624bcf09e221079edd498fac85a5f2c1404f` 展示已提交核心结构，本次未更新业务架构；定制查看器的浏览器回执与原生成回执分别记录。来源 [[raw/changes/2026-11-07-archify-node-documents]]；详情见 [[concepts/architecture-node-notes]]。
