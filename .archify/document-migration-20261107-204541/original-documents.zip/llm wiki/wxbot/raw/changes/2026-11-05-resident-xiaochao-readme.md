---
type: change
title: 复核常驻角色的 README 来源
pages:
- modules/wiki
---
# 复核常驻角色的 README 来源

## 目标与背景

补充 [[raw/changes/2026-11-05-resident-xiaochao]] 的 README 来源核对。

## 文件与代码位置

`README.md:819` 追加小潮的使用说明。`README.md:786` 的图谱维护章节经核对未移动，图谱工具仍沿用该入口。

## 接口与字段

不涉及图谱接口和字段。

## 数据库与迁移

不涉及数据库和迁移。

## 前端消费点

不涉及前端消费。

## 测试与异步任务

以 `wiki.py ingest` 和 `wiki.py lint` 核对来源。此条不涉及运行测试或异步任务。

## 风险与回滚

此条登记 README 证据快照，后续修订沿用追加记录的回滚方式。
