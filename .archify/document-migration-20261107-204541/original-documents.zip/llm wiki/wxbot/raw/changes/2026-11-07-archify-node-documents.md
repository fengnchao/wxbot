---
type: change
title: Archify 节点详情加入 Markdown 文档按钮
pages:
- concepts/architecture-node-notes
- concepts/development-baseline
- modules/wiki
---
# Archify 节点详情加入 Markdown 文档按钮

## 目标与背景

用户要求对比根目录 ARCHITECTURE.html 与现有 Archify 图，把节点 Markdown 功能接入后者，在既有节点弹窗增加一个小按钮。复用原有 architecture-notes 文件，保留节点和连接。当前工作目录 D:/work/code/wxbot，分支 codex/index-tts-skill，HEAD 20fc624bcf09e221079edd498fac85a5f2c1404f，工作区原有未提交工作全部保留。

## 文件与代码位置

- 交付页 `.archify/architecture-wxbot-20261107-201947/wxbot.html:5673` 注入文档按钮，`:15013` 起加入独立主题样式、dialog 与脚本；读取 `:15145`，保存 `:15249`。
- 同目录 `node-notes.extension.html` 保存可重复应用的扩展源；`apply-node-notes.py` 幂等注入，并保留首次应用前 HTML。
- 原图 `ARCHITECTURE.html:294–503` 提供编辑器参考；原图自身和已有 Markdown 文件均未修改。
- README.md:859 追加使用说明。三个图谱词条核对 README 原锚点，更新本功能及来源；coverage/index/changelog/ingest-state 随入库更新。

## 接口与字段

不涉及 HTTP API/DTO 或业务字段。浏览器本地新增 #btn-node-note；节点 ID 通过固定映射找到 Markdown 文件键。web 与 dashboard 共用 dashboard.md；新语义节点使用 model-backends、identity-tools、knowledge-vault、configuration。仅读取 architecture-notes，目录选择必须验证根目录 ARCHITECTURE.html。保存复用独占 writer、前后内容复核与失败时保留草稿。

## 数据库与迁移

不涉及数据库、表字段或迁移。该页面只通过用户授权的 File System Access 句柄读写项目 Markdown；不读 runtime 配置、消息、凭据或数据库。

## 前端消费点

仅独立 HTML：原生节点详情显示文档按钮，点击打开 Markdown 原文弹窗。弹窗是 focus-chip 子节点，避免查看器捕获阶段的外部点击逻辑清除选中状态。隔离编辑器快捷键，关闭后恢复焦点。多节点和关系选择隐藏文档按钮。深浅主题和打印状态使用本地样式适配。不改 web/，无 npm build/smoke 或 Hallmark web 页面工作流。

## 测试与异步任务

- 先运行浏览器用例确认缺少文档按钮的预期失败，再实现功能。
- 同目录 node-notes.test.cjs 使用隔离无头 Edge 和内存目录/文件句柄：权限取消/拒绝、选错根目录、文本安全预览、读取/保存、全部 12 个节点映射、授权复用、新文件延迟创建、外部改动冲突、草稿保护、焦点恢复、多选/关系状态隐藏、深浅主题、弹窗居中、窄窗口、快捷键隔离、不支持浏览器与无页面异常均通过。
- 截图人工检查小按钮和居中弹窗；当前字节摘要记录 node-notes-verification.json。原生成回执只对应扩展前字节，不宣称覆盖扩展。
- 幂等应用及字节比对通过：除小按钮和完整扩展片段外，原 HTML 不变；再次应用字节不变，浏览器回执摘要与最终页一致。
- 不涉及业务后台任务、服务重启、真实微信发送或真实笔记写入。测试全部使用内存假数据。
- 变更前 wiki lint 已有两个未入库历史记录：2026-11-03-feat-voice-002-indextts、2026-11-03-indextts-enqueue-media；本次不擅自入库这些历史工作。

## 风险与回滚

浏览器需 Edge/Chrome 文件系统 API 和用户选择项目目录授权；读取失败、选错目录、外部改动和未保存草稿有提示。权限仅在当前页面会话复用。原功能的文件竞态边界沿用，未声称浏览器文件写入与外部编辑器间具备跨进程事务。未来重新渲染会移除扩展，运行 apply-node-notes.py 可恢复；若查看器节点详情结构改变，脚本明确失败，须先核对插入点。回滚用同目录 wxbot.before-node-notes.html 恢复，保留 architecture-notes 中的用户文档。
