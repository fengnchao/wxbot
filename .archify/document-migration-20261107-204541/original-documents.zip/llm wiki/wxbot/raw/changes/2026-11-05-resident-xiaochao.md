---
type: change
title: 小潮常驻角色与空闲刷抖音
pages:
- symbols/resident-role
- modules/runtime
- modules/plugin
- modules/butler
- apis/butler-handle
- apis/butler-handle-stream
- apis/dashboard-knowledge
- apis/index-tts
- concepts/development-baseline
- concepts/model-error-contract
- symbols/butler-handle
- symbols/butler-result
- symbols/knowledge-auto
- symbols/knowledge-extract
- tables/kb-episodes
---
# 小潮常驻角色与空闲刷抖音

## 目标与背景

小潮随本机 Butler 启停。服务空闲时短时浏览抖音推荐流，仅将本轮核对的播放记录写入本机日记。改前设计见 [[impacts/2026-11-05-resident-xiaochao]]。

## 文件与代码位置

`src/butler/config.py:22` 定义配置。`src/butler/server.py:425` 记录两个聊天入口的前台活动，`:513` 管理启停。`src/butler/runtime/resident.py:91` 管理调度和日记，`src/butler/runtime/resident_douyin.py:89` 通过可选 Playwright 控制专用 Edge。`src/butler/__main__.py:47` 提供显式登录，角色正文在 `plugins/butler-wechat/resident/xiao-chao.md:1`。

## 接口与字段

TOML `[resident_role]` 新增 `enabled`、`idle_seconds`、`round_seconds`、`cooldown_seconds`、`daily_seconds`，默认依次为 `false`、300、180、1800、900。CLI 新增 `resident-login`。HTTP 请求与响应字段不涉及，已复核鉴权、流式响应和共享文件内其余接口的来源。`pyproject.toml` 新增可选依赖 `resident`。

## 数据库与迁移

数据库和迁移不涉及。角色状态、登录恢复标记、Edge 资料及日记存放在 `data/resident/xiao-chao/`。运行前原子写入额度预留和下次时间，结束后按浏览器活动用时归还未使用的部分。跨进程单飞锁保护运行状态。

## 前端消费点

不涉及管理台页面。使用者按 README 配置开关，通过本机日志、状态 JSON 和 Markdown 日记核对运行。

## 测试与异步任务

离线测试覆盖同步／流式聊天前台信号、生命周期、并发聊天、冷却、每日额度、登录恢复和短日记。后台线程空闲时唤醒，收到聊天时在下一次浏览操作前让路。兼容纯文本后端最多整理一次，其他后端写事实版日记。

## 风险与回滚

网页结构、登录和无窗口播放影响实际运行。只记录可核对的作品和播放进度，登录或验证交回使用者。停用开关并由用户重启 Butler 可回滚行为，浏览器资料和日记在本机保留。
