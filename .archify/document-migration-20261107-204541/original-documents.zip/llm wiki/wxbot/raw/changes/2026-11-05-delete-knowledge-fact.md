---
type: change
title: 知识库逐条删除事实
pages:
- apis/dashboard-knowledge
- tables/knowledge-vault
- modules/web
- modules/dashboard
- modules/butler
- symbols/knowledge-auto
- symbols/knowledge-extract
- tables/kb-episodes
- tables/kb-facts
- tables/kb-owners
- apis/index-tts
- apis/dashboard-workflow
- apis/dashboard-voice-assets
- apis/dashboard-queue
- apis/butler-handle
- apis/butler-handle-stream
- symbols/butler-handle
- symbols/butler-result
- concepts/model-error-contract
- concepts/development-baseline
- modules/wiki
---
# 修改记录

## 目标与背景

在知识库按条删除事实，保留对话原文和来源归属。原页面只有事实查询，不能清理个别错误或冗余事实。

## 文件与代码位置

- `web/src/views/FactsView.vue:155` 确认、发送及刷新；`web/src/styles/knowledge.css` 提供危险操作按钮与焦点样式，`web/dist` 随源码重建。
- `src/dashboard/routes.py:80` 与 `src/dashboard/api/knowledge.py:56` 注册本机转发。`src/dashboard/knowledge_view.py` 暴露事实编号和实时事实数。
- `src/butler/server.py:335` 提供鉴权写端点；`src/butler/runtime/knowledge_store.py:516` 删除精确事实行，更新索引。`src/butler/__main__.py` 的手动清理复用同一把提炼锁。

## 接口与字段

`GET /api/knowledge/facts` 返回 `fact_id`，由 owner、相对节点路径和事实行生成。`POST /api/knowledge/facts/delete` 要求同源和 `X-Wxbot-Knowledge-Action`，用服务 token 转发 `/v1/knowledge/facts/delete`。请求只收 `owner/fact_id/acknowledge`；成功返回 `ok/deleted/indexes_updated`，已变更或已删 404，更新占锁 409，输入错误 400。

## 数据库与迁移

不涉及 DB 和迁移。节点内只原子替换目标事实行，原文、其他事实、节点文件、owner 及提炼游标保留。刷新目录事实数和 vault 中心索引。若派生索引写入失败，告知已删除且索引暂未更新，管理台统计仍按实际节点读取。

## 前端消费点

逐条按钮明确显示确认内容、处理中、成功和错误；取消不会发写请求。沿用群筛选、个人筛选和分页，末页清空时回到最后一个有数据的页。

## 测试与异步任务

临时库 49 项离线回归、前端 build 和 smoke、Hallmark 静态检查通过。覆盖同文多节点、重试、原文、游标、确认、占锁和索引失败。浏览器进程启动受限。不新增后台任务，提炼及定期清理与删除共享锁。

## 风险与回滚

用户点击确认后按条永久删除，恢复依赖原有备份；游标不重置，但以后新消息仍可能提炼出类似事实。回滚源码和 dist 即移除入口，不能恢复已删除内容。详见 [[impacts/2026-11-05-delete-knowledge-fact]]。
