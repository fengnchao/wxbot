---
type: change
title: 管理台查看小潮日记
pages:
- apis/dashboard-resident-diary
- modules/dashboard
- modules/web
- modules/wiki
- symbols/resident-role
- concepts/development-baseline
- apis/dashboard-knowledge
- apis/dashboard-queue
- apis/dashboard-voice-assets
- apis/dashboard-workflow
- tables/knowledge-vault
---
# 管理台查看小潮日记

## 目标与背景

在本机管理台提供「小潮日记」，读取常驻角色已完成的 Markdown 文件。改前核对见 [[impacts/2026-11-05-resident-diary-web]]。

## 文件与代码位置

`src/dashboard/api/resident_diary.py:16` 解码实际日记结构，`:38` 读取并分页。`src/dashboard/routes.py:20,64` 注册本机业务 GET。`web/src/router.js:13`、`web/src/App.vue:26` 注册页面，`web/src/views/ResidentDiaryView.vue:25` 调用接口。

## 接口与字段

`GET /api/resident/diary?page=1` 返回 `entries`、`page`、`pages`、`total`。每页 20 条。条目含 `id`、`date`、`updated_at`、`note`、`videos`。文件目录来自 Butler 配置。目录不存在返回空列表，外部模式沿用业务路由的 503。共享路由中的其他接口已核对。

## 数据库与迁移

数据库和迁移不涉及。源文件由 [[symbols/resident-role]] 写入，管理台只读。日期和 ID 来自文件名，显示时间来自文件修改时间。只读取固定目录中的常规日记文件。

## 前端消费点

「用户与任务 → 小潮日记」展示日期、正文、可核对的抖音作品与播放时长。正文以文本渲染。刷新沿用主壳，页码保存在地址栏。包含加载、空、错误和正常状态。按项目流程构建 `web/dist/`。

## 测试与异步任务

离线测试覆盖路径边界、非预期 URL、排序、分页和空态。管理台冒烟覆盖页面入口、文本安全、视频链接、翻页、刷新失败与重试空态。独立预览用隔离日记核对桌面与窄屏布局。新增异步任务不涉及。

## 风险与回滚

日记格式改版时，无法识别的内容以文本展示。回滚移除管理台入口、接口和对应构建产物即可，原日记可继续读取。
