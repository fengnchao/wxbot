---
type: change
title: 知识库按群汇总并标记来源
pages:
- apis/dashboard-knowledge
- modules/dashboard
- modules/web
- tables/knowledge-vault
- tables/kb-episodes
- tables/kb-facts
- tables/kb-owners
- symbols/knowledge-extract
---
# 修改记录

## 目标与背景

群成员原文和事实按 owner 留在各自 vault。知识库页面曾用群窗口名显示每个 owner，多个档案看起来相同。现按群窗口汇总并展示事实所属群与归档成员。

## 文件与代码位置

- `src/dashboard/knowledge_view.py` 的 `_identity_names` 和 `_fact_groups` 建立只读来源与汇总，`facts` 计算筛选和展示字段。`src/dashboard/api/knowledge.py` 的 `facts` 传入群筛选与本地身份库路径。
- `src/butler/runtime/knowledge_store.py:671` 的 `facts` 在原全局时间排序与分页前允许限定 owner 集合。
- `web/src/views/FactsView.vue` 以群为可筛选项，事实表「来源」显示成员和群名。`web/src/styles/knowledge.css` 允许来源列折行，随源码重建 dist。

## 接口与字段

现有 GET `/api/knowledge/facts` 增加可选精确 `group`，优先于 `contact` 并可与 `owner` 联合过滤。响应增加 `groups[{name,facts,episodes}]`、`owners[].group_only` 和可确定群归档的事实 `source_group/source_name`。保持原文接口及已有个人过滤的形态。

## 数据库与迁移

不涉及迁移、写库、合并联系人或改写 Markdown。群原文计数和通道来自现有日记块，事实计数来自节点 contact。保留已无原文但目录标为群聊的归档来源。某 owner 的同名群和私聊均有原文时，旧事实缺少逐条通道，不把该 owner 的同名事实归进群筛选。成员来源取业务库的已确认群昵称、人物显示名或明确的未知标签。

## 前端消费点

知识库左栏显示每群一项，纯群归档折入群条目，混合归档可继续用个人筛选。群筛选先于分页且保留搜索；选群时原全局提炼按钮标明「立即提炼全部」。对话记录页面继续使用原投影。

## 测试与异步任务

临时库回归覆盖多 owner、匿名、同名私聊、分页及原记录保留，20 项离线测试通过。Vite build、smoke 与 Hallmark 静态检查通过；浏览器进程启动受限。不涉及提炼调度或新增异步任务。

## 风险与回滚

历史事实仅有归档范围，来源标签描述归档归属，无法给所有旧事实补出原消息通道。回滚源码与 dist 即恢复旧列表；不改业务数据。详见 [[impacts/2026-11-05-knowledge-group-sources]]。
