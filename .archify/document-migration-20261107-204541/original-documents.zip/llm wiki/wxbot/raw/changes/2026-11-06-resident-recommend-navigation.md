---
type: change
title: 修复小潮推荐流跳转到精选
pages:
- symbols/resident-role
---
# 修复小潮推荐流跳转到精选

## 目标与背景

旧入口 `/?recommend=1` 在可见 Edge 中跳转到 `/jingxuan`，此时没有可识别的推荐流播放器，轮次记录为 `no_playback`。尝试直接访问 `/recommend` 也出现同样的跳转。恢复从站内推荐入口寻找播放器。

## 文件与代码位置

`src/butler/runtime/resident_douyin.py:11` 的 `FEED_URL` 带上 `from_nav=1`。`src/butler/runtime/resident_douyin.py:126` 的 `_follow_recommend_link` 限制来源、可访问名称、站内目标和停止条件。`src/butler/runtime/resident_douyin.py:144` 的 `_wait_for_access` 与 `src/butler/runtime/resident_douyin.py:165` 的 `watch` 在精选无作品时允许站内回退。

## 接口与字段

HTTP API、配置字段和状态格式无变化。

## 数据库与迁移

不涉及数据库和迁移。

## 前端消费点

不涉及前端变更。日记仍只显示实际记录到播放的轮次。

## 测试与异步任务

本地回归模拟精选跳转、站内回退与拦截站外链接。常驻角色、心跳及日记 API 共 38 个测试通过。导航沿用现有的前台活动、时限和冷却规则。

## 风险与回滚

抖音页面结构变化可能影响链接和作品识别。新入口在真实已登录浏览器中的复测遇到自动审批超时。运行中的 Butler 需重新启动以加载代码。回滚仅涉及推荐 URL 和导航回退逻辑，无数据迁移。
