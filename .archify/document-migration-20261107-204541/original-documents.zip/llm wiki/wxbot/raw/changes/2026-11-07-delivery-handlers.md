---
type: change
title: 发件处理器按类型拆分，保留统一队列与投递契约
pages:
- apis/index-tts
- concepts/architecture-node-notes
- concepts/automatic-voice-reply
- concepts/delivery-state
- concepts/development-baseline
- concepts/voice-asset-binding
- modules/wiki
- tables/queue-outbox
- modules/wxbot
- concepts/message-pipeline
- symbols/queue-store
- symbols/delivery-pump
- symbols/delivery-handlers
---

# 发件处理器按类型拆分

## 目标与背景

用户批准架构重构第一步。将现有文字、语音、图片、表情执行分开，保留一个队列调度器和现有投递行为。影响分析见 [[impacts/2026-11-07-delivery-handlers]]。

## 文件与代码位置

- src/wxbot/delivery.py:15 DeliveryPump；:97 _finish；:201 start_next；:211 tick；:262 reconcile。
- src/wxbot/delivery_handlers/base.py:19 生命周期；bubble.py:7 共用气泡保护；text.py:22 正文/流式；image.py:5 图片；voice.py:6 音频/PTT/回退；emoji.py:5 表情；__init__.py:8 固定 registry。
- README.md 文件职责和架构章节同步；ARCHITECTURE.html 添加调度器与四处理器、29 个节点和对应 architecture-notes 文档，明确未来分流与前置 TTS。
- 新建 symbols/delivery-pump 与 symbols/delivery-handlers；已更新相关来源锚点、反向调用、README 摘要与覆盖表。

## 接口与字段

DeliveryPump 公开构造和方法、ActiveDelivery/reply_evidence/reply_is_visible 导入保持兼容。语音内部方法移入 voice_handler；本地测试只调整私有调用地址，保留断言。
无 HTTP/DTO/配置变更；按现有 kind 分派。不新增 reply_type 或 file，不前移 TTS。

## 数据库与迁移

不涉及迁移。outbox/schema/version、claim_delivery/recover 未改。统一认领后按 kind 分派，跨类型顺序仍受原 contact/seq 约束。包回执、草稿、未确认结果和单次语音回退字段保持原血缘。

## 前端消费点

web/ 源码、构建产物和管理台队列 API 不涉及；HTTP 和 DB 无变化，无需适配。
仅根 HTML 架构文档新增已实现处理器与路径，所有新增节点绑定真实 Markdown；其编辑器脚本未修改。

## 测试与异步任务

基线相关回归 229 通过/2 失败；拆分后同范围加 7 项测试为 236 通过/2 个相同失败。核心回归 92 通过。
全项目回归 1576 通过/4 失败；四项均用拆分前发件源码在独立测试进程复现。详情与测试名见 docs/superpowers/plans/2026-11-07-delivery-handlers-verification.md。
未发送真实微信，未重启服务。语音处理器持有原单 daemon Future；后台只准备音频，UI 线程恢复前检查行、开关和音色。
独立代码审查未发现引入的正确性回归；保留“合成中删除/跳过行”的专门回归缺口，原失效行保护已保留。

## 风险与回滚

主要风险为混合顺序、重复回退、预设撤权、图片残留和流式提前提交；现有离线回归加新混合/重启用例验证。
原有四条测试失败和两条旧 pending-change 不冒充本次已解决。新增图示仍保留部分目标架构，不能推断所有规划已实现。
回滚本次 delivery.py/新处理器和相应文档即可，无数据迁移或配置恢复。保留其他已有未提交工作。
