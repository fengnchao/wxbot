---
type: change
title: 架构图节点 Markdown 文档
pages:
- concepts/architecture-node-notes
- modules/wiki
---
# 架构图节点 Markdown 文档

## 目标与背景

在项目根目录架构图上点击节点即可查看或编辑该节点的 Markdown 文件。

## 文件与代码位置

`ARCHITECTURE.html:79` 起定义节点键；`ARCHITECTURE.html:357` 是查看编辑对话框。
`ARCHITECTURE.html:425` 读取文档，`ARCHITECTURE.html:494` 选择项目目录，
`ARCHITECTURE.html:527` 打开写入流。核对 `AGENTS.md:36` 的图谱章节位置并修正已漂移的导航锚点。

## 接口与字段

不涉及 HTTP API 或 DTO。SVG 上的 `data-note` 映射到项目目录下的
`architecture-notes/<键>.md`；`data-component` 是节点显示名。
用户通过浏览器目录选择器授予文件读写权限。

## 数据库与迁移

不涉及数据库、迁移或运行时数据；节点文档是独立的文本文件。

## 前端消费点

独立的 `ARCHITECTURE.html` 打开并编辑 Markdown 源文，主图和发件分流的同名组件复用文档键。
Vue 管理台不消费节点文档。

## 测试与异步任务

验证 SVG 的 35 个入口及 30 个文档键，并在 Edge 中检查交互。无新增后台任务。

## 风险与回滚

本地读写依赖支持 File System Access API 的浏览器及用户目录授权。
检测到外部改写时保留编辑草稿。回滚页面交互后，已保存的 Markdown 仍可用文本编辑器打开。
