---
type: change
title: 修正四项过期回归预期并补边界对照
pages:
- modules/plugin
- concepts/delivery-state
- symbols/queue-store
- concepts/development-baseline
---

# 四项历史失败的测试合同修正

## 目标与背景

用户要求修复重构前已存在的四个测试失败。改前独立复现 4 失败，核对源代码、README 和已通过的生命周期用例后确认全部是旧预期。保留当前生产行为，修正测试并增加边界对照。
影响报告：[[impacts/2026-11-07-stale-regression-tests]]。

## 文件与代码位置

- tests/integration/test_portable_install.py：由固定技能数量改为实际文件完整导出和核心技能路径校验。
- tests/unit/queue/test_queue_admin.py：参数化 CLI sent/retry，只恢复/确认选中段，前段与已停止后段保持完整记录不变。
- tests/unit/queue/test_queue_store.py：恢复后的待核对记录不阻塞新轮；补 sending/confirming 活跃任务登记正文后仍阻塞的对照。
- tests/unit/text/test_typing.py：分别验证默认 0.25 秒与显式 0.5 秒，保留粘贴正文、单次提交和剪贴板恢复。
- architecture-notes/delivery-pump.md 补充 done 与送达状态的区别；ARCHITECTURE.html 已复核，组件和连接未变化。
- tests/ 按仓库规则仅本地保存且不入 Git；图谱来源仍使用已核对的生产源码。

## 接口与字段

不涉及生产接口或 DTO 变更。技能 manifest、队列 API、typing 配置合同保持原状。

## 数据库与迁移

不涉及。现有 outbox/batches 状态、detached、submitted_text 和 resolve/retry 的血缘已复核；没有迁移或生产数据库访问。

## 前端消费点

不涉及 web/ 源码、构建产物或管理台接口。架构节点笔记只是补充已有规则。

## 测试与异步任务

四项原失败先复现；调整后扩展为 8 项用例全部通过。全项目 `python -m pytest` 为 1584 通过、0 失败、3 条原有 Pillow 弃用提示，耗时 121.72 秒。本次不新增异步任务。
用临时库、假窗口/剪贴板及随机本机 HTTP 替身；没有发真实微信，没有重启现有服务。

## 风险与回滚

风险是通过放宽预期掩盖错误，因此保留精确状态/正文/先后顺序断言，并加入相反状态对照。
本次没有改产品行为。回滚四个本地测试文件和相关开发说明即可；不回滚其他已有未提交工作。
旧记录中四项失败是当时运行结果，保留历史；本记录说明之后的处理结果，不改写已入库 raw。
