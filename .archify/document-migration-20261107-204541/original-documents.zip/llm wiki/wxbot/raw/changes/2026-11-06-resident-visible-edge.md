---
type: change
title: 小潮有窗口模式与同页验证恢复
pages:
- symbols/resident-role
- concepts/development-baseline
- modules/wiki
---
# 小潮有窗口模式与同页验证恢复

## 目标与背景

为 [[symbols/resident-role]] 增加有窗口浏览。复现表明无窗口推荐页可能在登录后要求安全验证，用户需要在同一浏览器处理。影响见 [[impacts/2026-11-06-resident-visible-edge]]。

## 文件与代码位置

`src/butler/config.py:22` 校验新设置。`src/butler/runtime/resident_douyin.py:124` 等待页面和登录恢复，`:141` 在同一 Edge 会话内暂停及继续。`src/butler/runtime/resident.py:141` 判断模式、更新状态和计算额度。README 记载操作步骤。

## 接口与字段

TOML 新增布尔值 `[resident_role].visible_browser`，缺省 `false`。无 HTTP 接口或 DTO 变化。`state.json` 保存 `visible_browser` 和临时状态 `verification_required`，旧记录缺省为无窗口。

## 数据库与迁移

无数据库或迁移。旧的登录等待在窗口模式变化时允许按调度规则重新尝试。使用同一个已有的专用 Edge 登录资料目录。

## 前端消费点

不涉及管理台页面。验证在活动实际使用的专用 Edge 中处理，服务日志提示当前操作。

## 测试与异步任务

回归覆盖旧状态切换、等待额度、同一会话继续、前台聊天优先、停止和超时。等待保留后台线程和单飞锁，整轮累计最多 10 分钟，等待时间从活动额度排除。恢复前复核空闲与日界。

## 风险与回滚

平台验证仍由用户处理。浏览器可见窗口可能获得焦点。设置 `visible_browser = false` 并由用户重启 Butler 可恢复无窗口模式，日记和账号资料保留。
