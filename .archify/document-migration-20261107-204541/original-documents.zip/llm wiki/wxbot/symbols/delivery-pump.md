---
type: symbol
module: wxbot
summary: 一张 outbox 的统一 UI 调度、类型分派、状态与回执
coverage: core
last_verified: '2026-11-07'
sources:
- path: src/wxbot/delivery.py
  line: 15
  anchor: 'class DeliveryPump:'
- path: src/wxbot/delivery.py
  line: 97
  anchor: 'def _finish(self, delivery, state,'
- path: src/wxbot/delivery.py
  line: 201
  anchor: 'def start_next(self):'
- path: src/wxbot/delivery.py
  line: 211
  anchor: 'def tick(self, *, allow_start=True):'
- path: src/wxbot/delivery.py
  line: 262
  anchor: 'def reconcile(self):'
changes:
- raw/changes/2026-11-07-delivery-handlers
calls:
- symbols/delivery-handlers
- symbols/queue-store
---
# 统一发件调度 DeliveryPump

所属 [[modules/wxbot]]。MainInbox 创建一个 Pump 并在 UI 主线程调用它；构造、enqueue/start_next/tick/close/reconcile/busy 接口保留。

## 调用与顺序

`start_next` 先检查活动 UI 任务、处理器准备状态和关闭状态，再通过 [[symbols/queue-store]] 的 claim_delivery 统一认领。
`handler_for(kind)` 选择 [[symbols/delivery-handlers]] 中的 text/voice/image/emoji。未知旧 kind 仍按既有文字兼容路径处理，不扩展 file 发送。
同会话跨类型 FIFO、失败阻塞/人工核对、不同会话轮转仍来自原 SQL，处理器没有私有数据库队列或并行 UI 消费线程。

## 状态与边界

`_finish` 合并处理器默认诊断、UI Session 诊断及提交状态，关闭 Session，然后按类型调整失败策略，持久化结果，再执行类型后处理和 HTTP 等待者/媒体包回执。
语音合成仍在认领之后：准备时 busy=false 允许收件，但 preparing 阻止第二次发件认领；poll 恢复录音后本 tick 结束。
close 取消未开始的 Future、丢弃晚到结果并关闭活动 Session。重启 reconcile 只核对已有文字证据，图片/语音不凭文字快照重发。

不改 [[tables/queue-outbox]]、HTTP、配置或管理台 DTO。reply_type 分流、持久 TTS 作业与文件发送尚未实现。

## 验证与来源

本地 `tests/unit/queue/test_delivery_handlers.py` 覆盖独立处理器、混合发送顺序、未确认图片不越序及重启不重发；原 queue/media/voice 回归保持断言。
参见 [[concepts/delivery-state]]、[[concepts/message-pipeline]]、[[raw/changes/2026-11-07-delivery-handlers]]。
