---
type: symbol
module: runtime
summary: 常驻角色按聊天空闲调度抖音观看，持久化额度与本机日记
coverage: core
last_verified: '2026-11-06'
sources:
- path: src/butler/runtime/resident.py
  line: 91
  anchor: 'class ResidentRole:'
- path: src/butler/runtime/resident.py
  line: 20
  anchor: 'class ForegroundActivity:'
- path: src/butler/runtime/resident_douyin.py
  line: 91
  anchor: 'class DouyinBrowser:'
- path: src/butler/runtime/resident_douyin.py
  line: 126
  anchor: 'def _follow_recommend_link('
- path: src/butler/runtime/resident_douyin.py
  line: 144
  anchor: 'def _wait_for_access('
- path: src/butler/config.py
  line: 22
  anchor: 'class ResidentSettings:'
- path: src/butler/server.py
  line: 513
  anchor: 'def serve(cfg: Config) -> int:'
- path: src/butler/__main__.py
  line: 47
  anchor: "if args.command == 'resident-login':"
- path: plugins/butler-wechat/resident/xiao-chao.md
  line: 1
  anchor: '# 小潮'
changes:
- raw/changes/2026-11-05-resident-xiaochao
- raw/changes/2026-11-05-resident-diary-web
- raw/changes/2026-11-06-resident-visible-edge
- raw/changes/2026-11-06-resident-recommend-navigation
---
# 小潮常驻角色

`serve` 在 `[resident_role].enabled` 开启时创建小潮并启动后台线程，退出时停止。有效同步和流式请求使用同一并发计数。所有聊天请求完成后重新计空闲。关联 [[modules/runtime]]、[[apis/butler-handle]]、[[apis/butler-handle-stream]]。

[[modules/plugin]] 分发小潮的角色正文，供后台日记使用。小潮拥有独立数据目录和浏览器会话。日记通过无业务工具的纯文本后端整理，模型不可用或前台忙时回退事实版。权限边界见 [[concepts/identity-authority]]。

Playwright 使用专用 Edge profile。登录命令在可见浏览器中由使用者操作。活动缺省使用无窗口模式，`visible_browser = true` 时打开专用窗口。该窗口遇到登录或验证要求会等待用户，整轮累计最多 10 分钟。识别到有效登录和作品页面后复核空闲条件，再在同一窗口继续。等待期间暂停自动换片，时间不计入观看额度。作品身份和同一来源的连续播放进度用于确认实际观察。日记记录可核对的标题、链接和播放时长。

`state.json` 保存北京时间日期、已用秒数、冷却、登录等待和最近日记文件。单飞锁内先预留本轮额度，结束后按浏览器活动用时退还未使用的部分，加载和换片也计入。中断时保留已核对的观察。遇到验证时，已经获得观看记录的轮次仍保留冷却。日记按一次活动一个独立文件写入。

来源 [[raw/changes/2026-11-05-resident-xiaochao]]。

## 小潮日记接入核对

日记生成后可从 [[apis/dashboard-resident-diary]] 查看。网页只读现有日记，数据根仍由 Butler 配置决定。 来源 [[raw/changes/2026-11-05-resident-diary-web]]。

`verification_required` 代表正在专用窗口等待人工处理。已结束的 `login_required` 记录由登录标记和浏览器模式共同决定是否继续等待，旧记录按无窗口处理。来源 [[raw/changes/2026-11-06-resident-visible-edge]]。

推荐流使用带 `from_nav=1` 的入口。浏览器落到抖音「精选」且未识别到作品时，本轮可通过页面内唯一且符合站内推荐路由的「推荐」链接重试一次。人工验证完成且登录有效后也支持此回退。导航前仍检查取消、前台请求和本轮时限。来源 [[raw/changes/2026-11-06-resident-recommend-navigation]]。
