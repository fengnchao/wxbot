---
type: symbol
module: wxbot
summary: 文字、语音、图片、表情独立发送处理器及共用气泡保护
coverage: core
last_verified: '2026-11-07'
sources:
- path: src/wxbot/delivery_handlers/__init__.py
  line: 8
  anchor: 'def create_handlers(pump):'
- path: src/wxbot/delivery_handlers/base.py
  line: 19
  anchor: 'class DeliveryHandler:'
- path: src/wxbot/delivery_handlers/bubble.py
  line: 7
  anchor: 'class BubbleDeliveryHandler(DeliveryHandler):'
- path: src/wxbot/delivery_handlers/text.py
  line: 22
  anchor: 'class TextDeliveryHandler(BubbleDeliveryHandler):'
- path: src/wxbot/delivery_handlers/image.py
  line: 5
  anchor: 'class ImageDeliveryHandler(BubbleDeliveryHandler):'
- path: src/wxbot/delivery_handlers/voice.py
  line: 6
  anchor: 'class VoiceDeliveryHandler(DeliveryHandler):'
- path: src/wxbot/delivery_handlers/emoji.py
  line: 5
  anchor: 'class EmojiDeliveryHandler(DeliveryHandler):'
changes:
- raw/changes/2026-11-07-delivery-handlers
called_by:
- symbols/delivery-pump
calls:
- symbols/queue-store
---
# 发件类型处理器

所属 [[modules/wxbot]]，由 [[symbols/delivery-pump]] 的固定 registry 创建，不是模型可注册的插件。
每个处理器持有 Pump 上下文；队列操作继续使用 [[symbols/queue-store]]，不从模型响应接受任意媒体路径或身份权限。

## 职责

| kind | 处理器 | 责任 |
|---|---|---|
| text | TextDeliveryHandler | 群提及、正文输入、流式封口、取消后草稿保护、自身气泡证据 |
| image | ImageDeliveryHandler | 原 ImageSession、可信路径、图片气泡确认、粘贴后失败人工核对 |
| voice | VoiceDeliveryHandler | WAV/TTS 准备、Future、模式/绑定复核、PTT 回执、一次文字回退 |
| emoji | EmojiDeliveryHandler | 原 send_sticker 及 sent/blocked/uncertain 映射 |

文字与图片继承 BubbleDeliveryHandler：共用目标准备、草稿归属、提交前捕获最新快照和包授权、确认时限。
文字的流式部分在 configure_input/sync_input 中处理；语音不走气泡核验，仍以 ptt_release 和 human_confirm_required 记录现有约定。

## 生命周期

start 创建 UI Session 或语音准备任务；sync_input 在下一步前同步文字增量；complete 在 Session 离开 typing 后处理回执。
failure_details 在 Session 诊断之前提供默认值，prepare_finish 在关闭 Session 后决定持久状态，after_finish 在状态保存后做原语音回退。
VoiceDeliveryHandler.poll 只在 UI 线程恢复任务，核对 outbox 行仍为 sending；close 后不再接收结果。
语音失败规则和准确音色复核见 [[concepts/automatic-voice-reply]]、[[concepts/voice-asset-binding]]，显式音频包见 [[apis/index-tts]]。

## 兼容与来源

`wxbot.delivery` 继续导出 ActiveDelivery、reply_evidence、reply_is_visible；仅本地测试访问的旧私有语音方法迁到 voice_handler。
未改变 DB/HTTP/配置。来源 [[raw/changes/2026-11-07-delivery-handlers]]。
