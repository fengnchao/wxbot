---
type: api
module: dashboard
summary: 队列分页诊断，展示状态和可用动作而不执行恢复
coverage: core
last_verified: '2026-11-06'
sources:
- path: src/dashboard/routes.py
  line: 47
  anchor: ("GET", "/api/queue", queue.read)
- path: src/dashboard/api/queue.py
  line: 10
  anchor: 'def read(ctx):'
- path: src/dashboard/queue_view.py
  line: 22
  anchor: def read(self, *, contact=
- path: src/dashboard/queue_view.py
  line: 170
  anchor: def _row(
- path: web/src/views/QueueView.vue
  line: 248
  anchor: apiGet('/api/queue?'
changes:
- raw/changes/2026-11-03-feat-voice-003-voice-assets
- raw/changes/2026-10-31-knowledge-graph-bootstrap
- raw/changes/2026-11-01-knowledge-episodes
- raw/changes/2026-11-01-knowledge-sharding
- raw/changes/2026-11-01-knowledge-auto
- raw/changes/2026-11-01-knowledge-vault-graph
- raw/changes/2026-11-02-knowledge-graph-template
- raw/changes/2026-11-04-webui-preset-binding
- raw/changes/2026-11-04-webui-preset-graph-note
- raw/changes/2026-11-05-delete-knowledge-fact
- raw/changes/2026-11-05-resident-diary-web
---
# GET /api/queue

## 请求

GET `/api/queue`；可选 contact（字符串过滤）、state（默认 all）、scope、order；limit 默认 50，视图截在 1..200；offset 默认 0 且非负；inbox_offset/batches_offset/outbox_offset/rounds_offset 单独分页，telegram_offset 默认 0。路由 → api.queue.read → QueueView.read；HTTP 访问控制属于 [[modules/dashboard]]。

## 响应

`read_only: true`、database、at、status/error、contacts、counts、pages、inbox/batches/outbox、events、actions_enabled、failure_timeout_seconds；成功读取还含 rounds；处理器添加 telegram。pages 各表 total/offset/limit/has_more。missing/error 状态可能缺少正常读取的扩展字段，前端须容忍。

`_row` 投影状态、part_count/sent_parts/completed_parts、时限和允许动作。actions_enabled 仅在 schema 最新时开启，GET 本身不执行动作；写动作走独立 API 及确认头。

## 消费与表

[[modules/web]] 的 QueueView.vue 使用 apiGet 消费；无 TypeScript DTO，实际字段消费者就在 Vue 和共用 JS 中。对应 [[tables/queue-inbox]]、[[tables/queue-batches]]、[[tables/queue-outbox]]，batch_id 保持反向关联。展示与 [[apis/dashboard-workflow]] 是不同投影。

## 测试与风险

本地 tests/dashboard/test_queue_actions.py、test_queue_cleanup_actions.py、test_flow_view.py 和 web/scripts/smoke.mjs。表变更需兼容旧库只读展示；不得为了 GET 成功而创建/迁移队列。生命周期见 [[concepts/delivery-state]]。

2026-11-01 起陆续新增的 [[apis/dashboard-knowledge]] 与队列无关：`/api/knowledge`、`/api/knowledge/facts`、`/api/knowledge/extract`、`/api/knowledge/template` 四条 GET 现在连排在 `:43`–`:46`，两条知识 POST 在 `:67`–`:68`。这些行都插在 `/api/queue` 之后，本接口仍在 `:42`；请求参数、响应字段与动作白名单一条未变。

## 代码依据

- `src/dashboard/routes.py:42` — `("GET", "/api/queue", queue.read)`
- `src/dashboard/api/queue.py:10` — `def read(ctx):`
- `src/dashboard/queue_view.py:22` — `def read(self, *, contact=`
- `src/dashboard/queue_view.py:170` — `def _row(`
- `web/src/views/QueueView.vue:248` — `apiGet('/api/queue?'`

## 入库来源

[[raw/changes/2026-10-31-knowledge-graph-bootstrap]]

[[raw/changes/2026-11-01-knowledge-episodes]]

[[raw/changes/2026-11-01-knowledge-sharding]]

[[raw/changes/2026-11-02-knowledge-graph-template]]


## 联系人语音配置核对

[[raw/changes/2026-11-04-webui-preset-binding]]：接入网页预设列表与会话默认绑定；原有接口保持，新增接口及可选音色参数见 [[apis/index-tts]]。


图谱契约说明来源：[[raw/changes/2026-11-04-webui-preset-graph-note]]。

## 本次核对

新增知识事实写端点，队列读接口沿用。 来源 [[raw/changes/2026-11-05-delete-knowledge-fact]]。

## 小潮日记接入核对

复核共享路由表，收发队列读接口与队列操作仍使用原处理器。 来源 [[raw/changes/2026-11-05-resident-diary-web]]。
