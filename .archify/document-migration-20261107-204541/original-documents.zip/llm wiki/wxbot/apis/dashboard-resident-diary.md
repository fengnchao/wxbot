---
type: api
module: dashboard
summary: 从 Butler 数据目录只读分页展示小潮日记和已核对的作品链接
coverage: core
last_verified: '2026-11-06'
sources:
- path: src/dashboard/api/resident_diary.py
  line: 38
  anchor: 'def read(ctx):'
- path: src/dashboard/api/resident_diary.py
  line: 16
  anchor: 'def _entry(path, day, updated_at):'
- path: src/dashboard/routes.py
  line: 64
  anchor: '("GET", "/api/resident/diary", resident_diary.read),'
- path: web/src/views/ResidentDiaryView.vue
  line: 25
  anchor: "apiGet('/api/resident/diary?page=' + page)"
- path: web/src/router.js
  line: 13
  anchor: "id: 'resident-diary'"
changes:
- raw/changes/2026-11-05-resident-diary-web
---
# 管理台小潮日记接口

`GET /api/resident/diary?page=1` 属于 [[modules/dashboard]] 本机业务接口。目录由配置指定的数据根与 [[symbols/resident-role]] 的 `resident_root` 组合，请求只提供页码。远端模式由现有路由门禁返回 503。

响应包含 `entries`、`page`、`pages`、`total`，每页 20 条。文件按文件名日期、修改时间和稳定名称倒序。条目包含 `id`、`date`、`updated_at` 秒时间戳、`note`、`videos`。只读取命名匹配的常规 Markdown，跳过临时文件、链接和超过 64 KiB 的文件。目录不存在返回空页。无法读取时提供 500 错误。

作品条目包含 `title`、`seconds` 和 `url`。链接匹配抖音规范作品地址。格式无法识别时保留纯文本，Vue 不解释任意 HTML。[[modules/web]] 的小潮日记页复用主壳刷新，翻页写入地址栏。没有数据库迁移或写入接口。

来源 [[raw/changes/2026-11-05-resident-diary-web]]。
