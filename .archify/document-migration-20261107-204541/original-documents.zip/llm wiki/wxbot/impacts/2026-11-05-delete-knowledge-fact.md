---
type: impact
status: completed
date: 2026-11-05
---
# 知识库逐条删除

## 入口与字段

沿 [[apis/dashboard-knowledge]]、[[tables/knowledge-vault]] 与 [[symbols/knowledge-auto]] 核对。`knowledge_store.py:191,671` 解析 Markdown 事实；事实列表新增从 owner、相对节点位置和事实行计算的 `fact_id`，旧事实无需迁移。

- `web/src/views/FactsView.vue:312` 新增逐条按钮和确认，成功刷新当前筛选及分页。
- `src/dashboard/routes.py:77`、`src/dashboard/api/knowledge.py:45` 新增本机确认 POST，经现有服务凭据转发到 `src/butler/server.py:335` 附近的 Butler 写端点。只收 owner、fact_id 和 acknowledge。
- Butler 复用知识提炼跨进程锁，存储复用进程内锁和原子替换，删除精确匹配的事实行并重建统计及索引。保留节点、原文和提炼游标。不新增 DB 字段、后台任务或删除聊天数据。

## 验证与回滚

临时库覆盖同文多节点、原文与游标、旧编号、并发提炼和索引写入失败。假数据验证确认、取消、错误及刷新。回滚代码和 dist 即移除功能，已删除的事实只能从既有备份恢复。

实际变更见 [[raw/changes/2026-11-05-delete-knowledge-fact]]。
