# 四项历史回归失败核对

用户已授权修复四个测试失败。当前源码和既有通过测试一致，失败用例仍断言旧合同；修复仅涉及本地测试与开发文档。

## 原因与依据

1. `tests/integration/test_portable_install.py:45` 固定期望 6 个技能。manifest 覆盖 roles/tools，当前有 7 个 SKILL.md，含已实现的 IndexTTS。改为核对实际技能是否完整导出及核心技能路径，保留目录边界、引导入口、MCP 和协议断言。
2. `tests/unit/queue/test_queue_admin.py:58` 仍期望 uncertain 之后继续第三段。`src/wxbot/queue_store.py:639 finish_delivery` 和 `delivery_policy.py:5 _end_reply` 已采用“保留待核对段、停止本轮余段”的规则。分别验证 CLI 确认与显式重试，只操作选中项，不复活被停止的后续段。
3. `tests/unit/queue/test_queue_store.py:182` 在 recover 后要求旧批次继续阻塞。`queue_store.py:717 recover` 将未知投递保留为 uncertain/detached，并关闭旧轮，放行新收件。`record_submitted_text` 只登记正文，不改变状态；补活跃 sending/confirming 的相反用例，确保实际发送中仍阻塞。
4. `tests/unit/text/test_typing.py:46` 使用缺省配置却要求 0.5 秒间隔。`src/wxbot/config.py:33 validate_typing_config`、`src/butler/defaults.py:13 wxbot_defaults` 和 README 均为 0.25 秒。参数化验证默认 0.25 与显式 0.5 秒，保留输入内容、单次回车和剪贴板恢复断言。

## 影响范围与风险

生产 Python、HTTP/DTO、前端、数据库/迁移、异步任务均不变。ARCHITECTURE.html 已复核，没有组件、接口或数据流变化；在调度器节点 Markdown 补充状态含义。
测试使用临时库、假 UI/剪贴板，不发送微信、不重启服务。
风险是修改预期掩盖回归，因此必须保留精确断言，并增加活跃任务阻塞、显式间隔和选中段重试的对照用例。
回滚本地测试改动及本次文档即可，不涉及数据回退。
