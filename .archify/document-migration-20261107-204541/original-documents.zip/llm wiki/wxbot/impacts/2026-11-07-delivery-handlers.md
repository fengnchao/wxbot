# 发件处理器拆分影响分析

状态：实施前源码已核对；本次仅结构重构，用户已授权第一步。

## 文件、入口和调用方

- `src/wxbot/delivery.py:42 DeliveryPump`：目前文字、图片、表情、语音及确认混在一个类内，拆到 `delivery_handlers/`。
- `src/wxbot/inbox.py:45 MainInbox`：继续持有同一个 Pump，UI 所有权和 busy 语义不变。
- `src/wxbot/queue_store.py:585 claim_delivery`：统一认领，SQL 按 contact/seq 阻止后项越过未终结前项；不拆表、不改 SQL。
- `src/wxbot/queue_worker.py:46 process_once`：仅生成/持久化回复，无本次改动。
- 原代码的私有语音测试调用调整到 voice 处理器；公开导入 DeliveryPump/ActiveDelivery/reply_evidence 保持兼容。

## 契约与字段血缘

ModelWorker/外发接口 → outbox.kind/text/media_path/package_id → Pump 认领 → 对应处理器 → 原窗口 Session → Pump.finish_delivery。
仍只有 text/voice/image/emoji；reply_type 和 file 未实现。HTTP/DTO 不变，前端队列和工作流继续读原状态/字段，无 UI 源码适配。
语音合成仍发生在认领后的投递准备阶段；不提前到模型线程，不添加持久 TTS 作业。

## DB、异步任务与风险

数据库迁移不涉及；outbox schema/version/claim/recover 均保持原实现。
WebUI 后台线程仅合成，Future/关闭/失效行检查由语音处理器持有，UI 动作仍在 Pump tick 所在线程。
主要风险：类型混发次序、回退重复、语音撤权、图片残留和流式未封口提交。

## 验证与回滚

使用本地 queue/media/automatic_voice_reply/tts_ptt/tts_transport/reply_delivery_lifecycle 离线测试，并补混合消息跨重启回归。全部使用临时数据和假 UI，不访问真实剪贴板。
同步 ARCHITECTURE.html、节点 Markdown 与源码图谱。回滚本次 Python 提取和相关文档即可，不迁移数据、不更改服务配置。
覆盖缺口：现有图谱无独立 DeliveryPump/类型处理器条目，本次补建。
