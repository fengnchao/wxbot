---
type: impact
status: completed
date: 2026-11-05
---
# 知识库按群汇总与来源标识

## 来源和缺口

[[apis/dashboard-knowledge]]、[[tables/knowledge-vault]]、[[concepts/message-pipeline]] 说明了 owner 分档与节点 contact，知识库侧栏缺少按群汇总和归档成员展示。旧事实只有节点级 contact，缺少逐条通道和消息标识。

## 改动与边界

- `src/dashboard/knowledge_view.py:42,71` 和 `src/dashboard/api/knowledge.py:10,40`：事实响应保留 owners，补充按群汇总、来源人名、群筛选。会话目录确认群来源，群和私聊同名且无法区分的事实不放入群筛选。
- `src/butler/runtime/knowledge_store.py:671`：在现有跨 vault 分页前接受已验证的 owner 集合，保留原调用。
- `web/src/views/FactsView.vue:36,229`：同群显示一项，事实表展示来源。保留个人筛选、搜索、分页和提炼入口。
- 群成员名从本地身份库只读解析，无 schema、vault、队列、后台提炼或权限迁移。回滚源码和 dist 即恢复原投影。

## 验证

临时库覆盖多成员同群、匿名、同名私聊、跨成员分页和旧事实保留，前端用假数据验证分组与来源。

实际变更见 [[raw/changes/2026-11-05-knowledge-group-sources]]。
