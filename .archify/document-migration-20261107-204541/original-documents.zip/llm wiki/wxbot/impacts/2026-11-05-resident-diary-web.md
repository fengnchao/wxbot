---
type: impact
status: completed
date: 2026-11-05
---
# 管理台小潮日记

[[symbols/resident-role]] 记录日记命名和写入位置。现有 [[modules/dashboard]] 与 [[modules/web]] 没有读取日记的契约。

- `src/dashboard/api/resident_diary.py` 复用 `src/butler/runtime/resident.py:43` 的数据根路径和 `:204` 的日记格式。`src/dashboard/routes.py` 注册本机只读 GET，按页返回最新的实际日记、文件时间和可核对作品；路径来自配置，目录为空时返回空列表。
- `web/src/router.js` 与 `web/src/App.vue` 注册「用户与任务 → 小潮日记」，`web/src/views/ResidentDiaryView.vue` 消费分页结果。沿用现有深色主题、刷新和外部接入模式入口规则。正文走 Vue 文本插值，作品链接仅允许规范抖音作品地址。
- 文件读取独立于调度、SQLite 和联系人数据。忽略目录外的文件、链接、非日记文件与临时文件。无写入、迁移或新后台任务。回滚移除路由、读接口和页面即可。
- 验证用临时目录覆盖排序、分页、空态和路径边界，前端冒烟覆盖入口、正文、翻页、刷新及错误态。实际 Vue 路由单独预览。

实现与验证记录见 [[raw/changes/2026-11-05-resident-diary-web]]。
