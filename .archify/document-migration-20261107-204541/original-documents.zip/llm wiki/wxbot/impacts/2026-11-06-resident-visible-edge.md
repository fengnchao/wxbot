---
type: impact
status: completed
date: 2026-11-06
---
# 小潮在同一个 Edge 窗口等待验证

本机复现显示，已保存的专用浏览器登录态可在无窗口 Edge 中读取。推荐页随后出现可见的安全验证框，触发 [[symbols/resident-role]] 的登录等待。用户已同意使用有窗口的专用浏览器。

- `src/butler/config.py:22` 新增 `[resident_role].visible_browser`，缺省沿用无窗口模式。本机通过显式配置使用有窗口模式。`src/butler/runtime/resident_douyin.py:122` 在同一浏览器中留出最长 10 分钟等待人工处理登录或验证，识别到已登录且作品页面可用后恢复。停止服务、关闭窗口和等待超时有独立退出路径。
- `src/butler/runtime/resident.py:140` 在状态中记录窗口模式。旧状态缺少字段时按无窗口处理，切换模式可以重新尝试。等待期间停止换片，暂扣的观看额度在本轮结束时按实际活动扣除。恢复浏览前复核前台忙碌与当天额度的时间边界。
- HTTP、管理台页面、日记接口、数据库迁移不涉及。预计触及配置解析、角色线程和独立浏览器。离线使用假时间、页面与浏览器验证恢复、等待上限、暂停和额度。启用需要使用者手动重启 Butler。回滚可将窗口配置关闭。

实现与验证见 [[raw/changes/2026-11-06-resident-visible-edge]]。
