# 表情处理器

实现：`src/wxbot/delivery_handlers/emoji.py` 的 EmojiDeliveryHandler。

调用原 send_sticker 并保存 sent、blocked 或 uncertain 状态。
目标窗口核对与失败诊断保持原行为，点击后无法确认时不自动重复点击。
与文字、图片、语音共用同一张 outbox 和统一调度器。
