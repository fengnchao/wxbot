# 业务存储

保存联系人、对话记录和提炼出的知识，图中以 SQLite 和 Obsidian 表示。
