# Codex

图中展示的模型后端，接收 Butler 的推理请求并返回结果。
