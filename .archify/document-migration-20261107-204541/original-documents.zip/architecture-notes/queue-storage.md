# 收发队列存储

收件、消息批次和发件状态存放在 SQLite 中。图中的分类队列表示消息的处理分支。

当前发件共用一张 outbox，kind 为 text / voice / image / emoji。第一步没有数据库迁移。
QueueStore.claim_delivery 按会话和 seq 保证跨类型顺序，并保留失败、人工核对、包内顺序与会话轮转规则。
文件发件、reply_type 分流和持久化的 TTS 准备队列尚未实现。
