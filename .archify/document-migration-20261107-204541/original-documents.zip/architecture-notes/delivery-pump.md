# 统一发件调度

实现：`src/wxbot/delivery.py` 的 DeliveryPump。

统一认领 SQLite outbox，按 kind 选择处理器；一个时刻只有一个 UI 发送任务。
负责回执、状态落库、失败维护、包授权和重启核对；不在不同处理器之间启动竞争窗口的线程。
同会话先后顺序由 QueueStore.claim_delivery 保证。HTTP、数据表和外部调用接口未改变。

批次 `done` 表示本轮调度已结束，不等同于每一段都已确认送达。发送结果不确定时，
该段保留 `uncertain` 待核对，后续未发段停止；人工重试只恢复选中段。
重启恢复后可放行新消息；仍在 `sending/confirming` 的活跃任务继续阻塞同会话下一轮。
