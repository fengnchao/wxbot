# 文字发件队列

保存待发送的文字回复，由界面线程发送至微信。

当前是 outbox.kind=text 的逻辑分支，由 TextDeliveryHandler 处理。
支持原有分批/整段/流式输入、群聊提及与草稿保护；新增自身气泡才确认发送。
未来由 Butler.reply_type 显式指定类型，本步不新增此字段。
