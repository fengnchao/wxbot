# 界面线程

在微信窗口采集消息、发送出队内容，并核对发送结果。

发件由 `src/wxbot/delivery.py` 的 DeliveryPump 统一调度，按 outbox.kind 调用文字、语音、图片、表情处理器。
所有窗口操作仍在 UI 线程；语音后台线程仅准备音频，完成后回 UI 线程录音。
