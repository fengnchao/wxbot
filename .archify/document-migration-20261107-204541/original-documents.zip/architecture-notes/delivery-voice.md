# 语音处理器

实现：`src/wxbot/delivery_handlers/voice.py` 的 VoiceDeliveryHandler。

持有音频准备 Future，选择 TTS 或已有可信 WAV，复核当前会话模式和音色绑定后启动 PTT。
沿用 ptt_release 回执，需人工核对声音是否送达；失败按原 replace/coexist 规则回退。
自动 WebUI 录音前失败只回退一次文字，关闭或删除后不使用晚到的合成结果。
后台只生成音频，窗口选择与录音在 UI 线程执行。
