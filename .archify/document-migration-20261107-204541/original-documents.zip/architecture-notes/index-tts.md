# IndexTTS

图中的位置表示规划：将文字合成为音频后再交给语音发件队列。

第一步的实际自动语音路径仍是 outbox → VoiceDeliveryHandler → TTS 适配器 → 微信 PTT。
WebUI 合成在后台线程完成，期间不占微信窗口；合成结束及按录音键前复核当前语音授权。
显式 Butler tts_generate 语音包保持先生成、再入队的现有路径。
