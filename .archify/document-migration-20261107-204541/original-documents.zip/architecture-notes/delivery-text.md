# 文字处理器

实现：`src/wxbot/delivery_handlers/text.py` 的 TextDeliveryHandler。

启动正文输入与群聊提及，处理流式增量、封口提交及取消后的草稿清理。
用新出现的自身气泡确认发送，保留引用证据和无引用时的文字降级。
与图片处理器共用 bubble.py 中的目标、草稿、提交前复核和确认时限。
