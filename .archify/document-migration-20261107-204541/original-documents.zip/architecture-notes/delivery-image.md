# 图片处理器

实现：`src/wxbot/delivery_handlers/image.py` 的 ImageDeliveryHandler。

使用可信媒体缓存路径启动原 ImageSession，核对图片预览及新增自身图片气泡。
已粘贴但未确认发送时保留人工核对标记；重启后不凭文字快照重发图片。
共用原图文包授权、顺序和回执规则，不扩展为任意文件发送。
